﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace DemoThreads
{
    
    public class Class1
    {
        public static void Main(string[] args)
        {
            ThreadingData td = new ThreadingData("Num", 53);

            Thread myThread = new Thread(new ThreadStart(ThreadStarting));
            Thread dataT1 = new Thread(new ThreadStart(td.ThreadProc));

            myThread.Priority = ThreadPriority.Highest;
            dataT1.Priority = ThreadPriority.Lowest;
            myThread.Start();
            dataT1.Start();


            Console.WriteLine("This is called after thread starts");

            dataT1.Join();
            Console.WriteLine("ThreadData has joined the main thread");
            Console.Read();
        }

        public static void ThreadStarting()
        {
            Console.WriteLine("Starting Thread");
            Thread.Sleep(1000);
            Console.WriteLine("Thread Finished");
        }

        
        
    }

    public class ThreadingData
    {
        private String ranLet;
        private int ranNum;

        public ThreadingData(string let, int num)
        {
            ranLet = let;
            ranNum = num;
        }

        public void ThreadProc()
        {
            Console.WriteLine(ranLet + " " + ranNum);
            Thread.Sleep(10000);
        }


    }



}
